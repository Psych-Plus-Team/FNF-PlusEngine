CLASS TEMPLATES
===============

These templates are not loaded automatically because they end in .template.
Copy them to scripts/classes/states/ or scripts/classes/substates/ and remove
.template from the file name to activate them.

The main-state templates use an alias to the native state, allowing you to
add overrides without copying the entire original engine class.
