SCRIPTS AND CLASSES GUIDE - FNF PlusEngine
===========================================

This folder contains scripts that can modify the behavior of your mod.
Example files are located in scripts/templates/. Copy them to the correct
folder and remove the .template extension before using them.

1. RECOMMENDED STRUCTURE
------------------------

scripts/
  readme.txt                         This guide
  script.lua / script.hx             Global mod script
  global/                             Organized global systems
  states/                             State-specific regular scripts
  substates/                          Substate-specific regular scripts
  classes/
    states/                           HScript state classes
    substates/                        HScript substate classes
    stages/                           HScript stage classes
    stages/objects/                   Stage helper classes
  templates/                          Copyable templates; not loaded directly

Extended classes use scripts/classes/. Do not place a template there until
you want to activate it: the engine may treat it as a real override.

2. REGULAR SCRIPTS VS HXSCRIPT CLASSES
--------------------------------------

A regular global script (Lua or HScript) is useful for events and mod logic.
An HScript class is a complete class that can extend an engine state, substate,
or stage.

Regular script examples:
  scripts/script.lua
  scripts/script.hx
  scripts/states/myState.lua
  scripts/substates/mySubstate.lua

Class examples:
  scripts/classes/states/MainMenuState.hx
  scripts/classes/states/MyState.hx
  scripts/classes/substates/PauseSubState.hx
  scripts/classes/stages/MyStage.hx

For a main-state override, the file name and class name must match. For
example, MainMenuState.hx must declare states.MainMenuState.

3. EXTENDABLE MAIN STATES
--------------------------

The engine supports these main state classes inside a mod:
  TitleState          Title/start screen
  MainMenuState       Main menu
  FreeplayState       Song list
  FreeplayState_Psych Psych-compatible Freeplay variant
  PauseSubState       Pause menu during gameplay

Ready-to-copy templates:
  templates/classes/states/TitleState.hx.template
  templates/classes/states/MainMenuState.hx.template
  templates/classes/states/FreeplayState.hx.template
  templates/classes/states/FreeplayState_Psych.hx.template
  templates/classes/substates/PauseSubState.hx.template
  templates/classes/states/ExampleState.hx.template

To activate a template:
  1. Copy it to scripts/classes/states/ or scripts/classes/substates/.
  2. Rename ExampleState if needed.
  3. Remove .template from the file name.
  4. Keep the package and class name consistent with the path.
  5. Return to Freeplay and press F5 to clear the HScript cache.

Main-state overrides extend the native state through an alias. This lets you
add behavior without copying the entire engine state. To replace a state
completely, create a new class extending MusicBeatState instead.

4. CUSTOM STATES
----------------

A custom state should extend MusicBeatState:

  package states;
  import backend.MusicBeatState;

  class MyState extends MusicBeatState {
    public function new() {
      super();
    }
  }

Open it from another script with:
  switchToState('MyState');

Arguments can be passed with switchToState('MyState', [value1]).
Custom states are resolved as states.MyState.

5. STAGE CLASSES
-----------------

Stage classes belong in scripts/classes/stages/MyStage.hx and must extend
backend.BaseStage. The class name must match the stage requested by the song,
for example stages/PhillyStreets.hx for the PhillyStreets stage.

Helper classes can be placed in stages/objects/ and imported by the main stage.
Review base_game/scripts/classes/stages/ for working examples. HScript has
some limitations with statics, enums, and certain compiler-only features, so
do not blindly port large native Haxe classes.

6. HOW DOES THE ENGINE LOAD MOD CLASSES?
----------------------------------------

ScriptRegistry searches for a class approximately in this order:
  - The explicitly requested mod.
  - The currently active mod.
  - Global and enabled mods.
  - The engine shared folder.
  - The shared mods folder.
  - base_game as the global Friday Night Funkin mod.

The main search roots are scripts/classes/... and classes/.... Therefore,
scripts/classes/states/MainMenuState.hx resolves as states.MainMenuState.
The engine creates an HScript world for that mod, loads its imports, and then
instantiates the class.

These classes are not compiled into the executable as native Haxe. They are
read and executed at runtime through HScript. They can therefore be changed
without rebuilding the engine, as long as the updated file is already inside
the mod folder used by the running game.

7. RELOADING CHANGES WITHOUT RESTARTING EVERYTHING
--------------------------------------------------

After modifying a class:
  - If you edit export/release/windows/bin/mods/..., return to Freeplay,
    press F5, and enter gameplay again.
  - If you edit My-Mod or base_game, run the build/test command to copy the
    files to export, then use the same F5 workflow.
  - If you are already inside a song, leave it first. An existing state
    instance is not safely replaced in the middle of a stage.

F5 clears ScriptRegistry, and entering gameplay reads the class again.
You do not need to close and reopen the entire game every time.

8. PRACTICAL RULES
------------------
  - Use matching file and class names, including capitalization.
  - Use / paths instead of backslashes in script references.
  - Do not duplicate a global class when a song script is enough.
  - For song logic use songs/<name>/script.lua or script.hx.
  - For reusable events use custom_events/.
  - For note behavior use custom_notetypes/.
  - Keep assets in their intended folders; Paths resolves them according to
    mod priority.
  - If a class fails, check the HScript error immediately before the fallback
    message: that is usually the real cause.
