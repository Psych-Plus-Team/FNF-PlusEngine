Optional New Freeplay platform icons go here.

Use lowercase PNG names that match your link platforms, for example:

  images/albumRoll/platformIcons/youtube.png
  images/albumRoll/platformIcons/soundcloud.png
  images/albumRoll/platformIcons/spotify.png

These are used by the song info/link area when metadata links are available.
