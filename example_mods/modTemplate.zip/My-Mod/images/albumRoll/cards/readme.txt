New Freeplay info card images go here.

Default lookup:

  images/albumRoll/cards/[song-name].png

In song_meta.json you can use any of these fields:

  "card"
  "cardImage"
  "cardKey"
  "infoCard"

A short value like "my-card" loads images/albumRoll/cards/my-card.png.
