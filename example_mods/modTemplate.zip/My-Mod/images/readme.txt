Put your images here!

You can put your custom logo or an image that you can use as a background here and edit the specific variables within gfDanceTitle.json.

New Freeplay assets live in albumRoll/.
Use albumRoll/[song-name].png for square covers and albumRoll/cards/[song-name].png for info cards.
Optional badges can go in albumRoll/licenses/ and platform icons in albumRoll/platformIcons/.

For more info, each subdirectory has a readme.txt file.
